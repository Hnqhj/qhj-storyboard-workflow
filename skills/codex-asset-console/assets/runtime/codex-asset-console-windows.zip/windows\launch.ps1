﻿param(
  [int]$Port = 9231,
  [string]$InstallDir = (Split-Path -Parent $PSScriptRoot),
  [string]$StateDir = (Join-Path $env:LOCALAPPDATA "CodexAssetConsole")
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
$launcherLog = Join-Path $StateDir "launcher.log"

function Write-LauncherLog([string]$Message) {
  Add-Content -LiteralPath $launcherLog -Value "$(Get-Date -Format o) $Message" -Encoding utf8
}

function Test-LocalPort([int]$Number) {
  $client = [System.Net.Sockets.TcpClient]::new()
  try {
    $task = $client.ConnectAsync("127.0.0.1", $Number)
    return $task.Wait(500) -and $client.Connected
  } catch {
    return $false
  } finally {
    $client.Dispose()
  }
}

function Test-CodexDebugPort([int]$Number) {
  try {
    $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Number/json/list" -TimeoutSec 1
    $codexTarget = @($targets) | Where-Object { $_.url -eq "app://-/index.html" } | Select-Object -First 1
    return [bool]$codexTarget
  } catch {
    return $false
  }
}

function Start-CodexWithDebug([string]$AppUserModelId, [string]$Arguments) {
  if (-not ('CodexAppActivation' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CodexAppActivation {
  [ComImport, Guid("45BA127D-10A8-46EA-8AB7-" + "56EA9078943C"), ClassInterface(ClassInterfaceType.None)]
  class Manager {}
  [ComImport, Guid("2e941141-7f97-4756-ba1d-" + "9decde894a3d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IManager {
    int ActivateApplication([MarshalAs(UnmanagedType.LPWStr)] string appUserModelId, [MarshalAs(UnmanagedType.LPWStr)] string arguments, uint options, out uint processId);
    int ActivateForFile([MarshalAs(UnmanagedType.LPWStr)] string appUserModelId, IntPtr itemArray, [MarshalAs(UnmanagedType.LPWStr)] string verb, out uint processId);
    int ActivateForProtocol([MarshalAs(UnmanagedType.LPWStr)] string appUserModelId, IntPtr itemArray, out uint processId);
  }
  public static uint Start(string appUserModelId, string arguments) {
    var manager = (IManager)(object)new Manager();
    uint processId;
    int hr = manager.ActivateApplication(appUserModelId, arguments, 0, out processId);
    if (hr < 0) Marshal.ThrowExceptionForHR(hr);
    return processId;
  }
}
'@
  }
  return [CodexAppActivation]::Start($AppUserModelId, $Arguments)
}

try {
  & (Join-Path $PSScriptRoot "start-injector.ps1") -Port $Port -InstallDir $InstallDir -StateDir $StateDir

  $package = Get-AppxPackage -Name "OpenAI.Codex" -ErrorAction Stop | Sort-Object Version -Descending | Select-Object -First 1
  $codexExe = Join-Path $package.InstallLocation "app\ChatGPT.exe"
  if (-not (Test-Path -LiteralPath $codexExe -PathType Leaf)) { throw "Codex executable not found" }

  if (Test-LocalPort $Port) {
    if (-not (Test-CodexDebugPort $Port)) {
      throw "Port $Port is already in use by another application"
    }
    Start-Process -FilePath $codexExe
    Write-LauncherLog "Activated an existing enhanced Codex instance."
    exit 0
  }

  try {
    $mainProcesses = @(Get-CimInstance Win32_Process | Where-Object {
      $_.Name -eq "ChatGPT.exe" -and
      $_.ExecutablePath -like "*OpenAI.Codex*" -and
      $_.CommandLine -notmatch "--type=" -and
      $_.ProcessId -eq (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1 -ExpandProperty Id)
    })
  } catch {
    throw
  }
  foreach ($item in $mainProcesses) {
    $process = Get-Process -Id $item.ProcessId -ErrorAction SilentlyContinue
    if ($process) {
      [void]$process.CloseMainWindow()
    }
  }

  if ($mainProcesses) {
    throw "检测到 Codex 已在运行，但它没有开启调试端口。请先完全退出 Codex，再重新双击 Codex Asset Console。"
  }

  $appId = 'OpenAI.Codex_2p2nqsd0c76g0!App'
  $debugArgs = "--remote-debugging-address=127.0.0.1 --remote-debugging-port=$Port --remote-allow-origins=http://127.0.0.1:$Port --enable-features=LocalNetworkAccessForSubframeNavigationsWarningOnly"
  [void](Start-CodexWithDebug -AppUserModelId $appId -Arguments $debugArgs)

  $deadline = (Get-Date).AddSeconds(15)
  while ((Get-Date) -lt $deadline -and -not (Test-CodexDebugPort $Port)) {
    Start-Sleep -Milliseconds 250
  }
  if (-not (Test-CodexDebugPort $Port)) { throw "Codex did not open a valid local debugging target" }
  Write-LauncherLog "Started Codex with the asset console on 127.0.0.1:$Port."
} catch {
  Write-LauncherLog "ERROR: $($_.Exception.Message)"
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show(
    "启动失败。详情已记录到：`n$launcherLog",
    "Codex 资产控制台",
    "OK",
    "Error"
  ) | Out-Null
  exit 1
}
